<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Initialize variables
$name = '';
$email = '';
$subject = '';
$message = '';
$success = '';
$error = '';

// If user is logged in, pre-fill their info
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_query = "SELECT full_name, email FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $user_query);
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($user = mysqli_fetch_assoc($result)) {
        $name = $user['full_name'];
        $email = $user['email'];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

    // Validate inputs
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = "All fields are required!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address!";
    } else {
        // Insert query into database
        $insert_query = "INSERT INTO user_queries (user_id, name, email, subject, message) 
                         VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $insert_query);
        mysqli_stmt_bind_param($stmt, 'issss', $user_id, $name, $email, $subject, $message);

        if (mysqli_stmt_execute($stmt)) {
            $success = "Thank you for contacting us! We'll get back to you soon.";
            // Clear form on success
            $name = $email = $subject = $message = '';

            // Send email notification (optional)
            $to = "admin@agriculture_assessment.com";
            $headers = "From: $email\r\n";
            $headers .= "Reply-To: $email\r\n";
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

            $email_body = "New Contact Form Submission:\n\n";
            $email_body .= "Name: $name\n";
            $email_body .= "Email: $email\n";
            $email_body .= "Subject: $subject\n";
            $email_body .= "Message:\n$message\n";

            mail($to, "New Contact Form: $subject", $email_body, $headers);
        } else {
            $error = "Error submitting your query. Please try again later.";
        }
    }
}

include 'header.php';
?>
<body style="background-image: url(images/3.jpg); background-size: cover;background-repeat: no-repeat;">
<main class="flex-1 p-8">
    
    <div class="max-w-3xl mx-auto">
        <h1 class="text-2xl font-bold  mb-6 text-white text-center">Contact Us</h1>
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <div class="bg-white p-6 rounded-lg shadow">
            <form method="POST" action="contact_us.php" class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="name" class="block text-gray-700 mb-1">Full Name</label>
                        <input type="text" id="name" name="name"
                            class="w-full p-2 border rounded focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            value="<?php echo htmlspecialchars($name); ?>" required>
                    </div>
                    <div>
                        <label for="email" class="block text-gray-700 mb-1">Email Address</label>
                        <input type="email" id="email" name="email"
                            class="w-full p-2 border rounded focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            value="<?php echo htmlspecialchars($email); ?>" required>
                    </div>
                </div>

                <div>
                    <label for="subject" class="block text-gray-700 mb-1">Subject</label>
                    <input type="text" id="subject" name="subject"
                        class="w-full p-2 border rounded focus:ring-2 focus:ring-green-500 focus:border-green-500"
                        value="<?php echo htmlspecialchars($subject); ?>" required>
                </div>

                <div>
                    <label for="message" class="block text-gray-700 mb-1">Your Message</label>
                    <textarea id="message" name="message" rows="5"
                        class="w-full p-2 border rounded focus:ring-2 focus:ring-green-500 focus:border-green-500" required><?php echo htmlspecialchars($message); ?></textarea>
                </div>

                <div class="flex justify-end">
                    <button type="submit"
                        class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded transition duration-200">
                        Send Message
                    </button>
                </div>
            </form>
        </div>

        
    </div>
</main>
</body>
<script>
    // Client-side validation
    document.querySelector('form').addEventListener('submit', function(e) {
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const subject = document.getElementById('subject').value.trim();
        const message = document.getElementById('message').value.trim();

        if (!name || !email || !subject || !message) {
            alert('Please fill in all fields');
            e.preventDefault();
            return false;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Please enter a valid email address');
            e.preventDefault();
            return false;
        }

        return true;
    });
</script>

<?php include 'footer.php'; ?>