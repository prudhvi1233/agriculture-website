<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Fetch farmer-specific data
$user_id = $_SESSION['user_id'];
$region = $_SESSION['region'];

// 1. Get quick stats
$stats_query = "SELECT 
    SUM(l.land_size) as total_land,
    COUNT(DISTINCT s.scheme_id) as active_schemes
    FROM lands l
    LEFT JOIN regions r ON l.region = r.region_name
    LEFT JOIN region_schemes rs ON r.region_id = rs.region_id
    LEFT JOIN beneficiary_schemes s ON rs.scheme_id = s.scheme_id
    WHERE l.user_id = ?";
$stmt = mysqli_prepare($conn, $stats_query);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$stats_result = mysqli_stmt_get_result($stmt);
$stats = mysqli_fetch_assoc($stats_result) ?: ['total_land' => 0, 'active_schemes' => 0];
mysqli_stmt_close($stmt);
mysqli_free_result($stats_result);

// 2. Get farmer's lands
$lands_query = "SELECT * FROM lands WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $lands_query);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$lands = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

// 3. Get scheme alerts
$schemes_query = "SELECT s.scheme_name, rs.implementation_status
                 FROM region_schemes rs
                 JOIN beneficiary_schemes s ON rs.scheme_id = s.scheme_id
                 JOIN regions r ON rs.region_id = r.region_id
                 WHERE r.region_name = ?
                 LIMIT 2";
$stmt = mysqli_prepare($conn, $schemes_query);
mysqli_stmt_bind_param($stmt, 's', $region);
mysqli_stmt_execute($stmt);
$schemes = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmer Dashboard | AgriData</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 py-6">
        <!-- Welcome Banner -->
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6">
            <h1 class="text-2xl font-bold">Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h1>
            <p>Your regional dashboard for <?php echo htmlspecialchars($region); ?></p>
        </div>

        <!-- Dashboard Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Left Column -->
            <div class="lg:col-span-2 space-y-6">
                <!-- Quick Stats -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-xl font-semibold mb-4 text-green-800">
                        <i class="fas fa-chart-line mr-2"></i>Your Quick Stats
                    </h2>
                    <div class="grid grid-cols-3 gap-4">
                        <div class="text-center p-4 bg-blue-50 rounded-lg">
                            <div class="text-3xl font-bold text-blue-600"><?php echo number_format($stats['total_land'], 2); ?> ha</div>
                            <div class="text-sm text-gray-600">Total Land</div>
                        </div>
                        <div class="text-center p-4 bg-green-50 rounded-lg">
                            <div class="text-3xl font-bold text-green-600"><?php echo $stats['active_schemes']; ?></div>
                            <div class="text-sm text-gray-600">Active Schemes</div>
                        </div>
                        <div class="text-center p-4 bg-yellow-50 rounded-lg">
                            <div class="text-3xl font-bold text-yellow-600">3.2t</div>
                            <div class="text-sm text-gray-600">Avg Yield</div>
                        </div>
                    </div>
                </div>

                <!-- My Lands -->
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-semibold text-green-800">
                            <i class="fas fa-tractor mr-2"></i>My Lands
                        </h2>
                        <a href="add_land.php" class="text-sm bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded">
                            <i class="fas fa-plus mr-1"></i>Add Land
                        </a>
                        <a href="view_lands.php" class="text-sm bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded">
                            View All Lands
                        </a>
                    </div>

                    <div class="space-y-3">
                        <?php if (mysqli_num_rows($lands) > 0): ?>
                            <?php while ($land = mysqli_fetch_assoc($lands)): ?>
                                <div class="border rounded-lg p-4 hover:bg-gray-50">
                                    <div class="flex justify-between">
                                        <div>
                                            <h3 class="font-medium"><?php echo htmlspecialchars($land['primary_crop']); ?> Field</h3>
                                            <p class="text-sm text-gray-600">
                                                <?php echo htmlspecialchars($land['land_size']); ?> ha •
                                                <?php echo htmlspecialchars($land['irrigation_source']); ?>
                                            </p>
                                        </div>
                                        <span class="px-2 py-1 text-xs rounded mt-3 bg-green-100 text-green-800">
                                            Active
                                        </span>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-gray-500">
                                <p>No lands registered yet</p>
                                <a href="add_land.php" class="text-green-600 hover:underline">Add your first land</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="space-y-6">
                <!-- Scheme Alerts -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-xl font-semibold mb-4 text-green-800">
                        <i class="fas fa-calendar-check mr-2"></i>Scheme Alerts
                    </h2>
                    <div class="space-y-3">
                        <?php if (mysqli_num_rows($schemes) > 0): ?>
                            <?php while ($scheme = mysqli_fetch_assoc($schemes)): ?>
                                <div class="p-3 bg-yellow-50 rounded-lg">
                                    <h3 class="font-medium"><?php echo htmlspecialchars($scheme['scheme_name']); ?></h3>
                                    <div class="text-sm mt-1">
                                        <span class="font-medium"><?php echo ucfirst($scheme['implementation_status']); ?></span>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-gray-500">No active schemes</p>
                        <?php endif; ?>
                        <a href="schemes.php" class="block text-center text-sm text-green-600 hover:underline mt-2">
                            View all schemes →
                        </a>
                    </div>
                </div>

                <!-- Weather Forecast -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-xl font-semibold mb-4 text-green-800">
                        <i class="fas fa-cloud-sun mr-2"></i>Weather Forecast
                    </h2>
                    <div class="text-center p-4 bg-blue-50 rounded-lg">
                        <div class="text-4xl font-bold text-blue-600">28°C</div>
                        <div class="text-gray-600 mb-2">Sunny</div>
                        <div class="grid grid-cols-3 gap-2 text-sm">
                            <div>
                                <div>Tomorrow</div>
                                <div class="font-medium">27°C</div>
                                <div class="text-gray-500">Partly Cloudy</div>
                            </div>
                            <div>
                                <div><?php echo date('D', strtotime('+2 days')); ?></div>
                                <div class="font-medium">26°C</div>
                                <div class="text-gray-500">Light Rain</div>
                            </div>
                            <div>
                                <div><?php echo date('D', strtotime('+3 days')); ?></div>
                                <div class="font-medium">25°C</div>
                                <div class="text-gray-500">Rain</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        // Simple script for mobile menu toggle if needed
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Dashboard loaded');
        });
    </script>
</body>
</html>
<?php
mysqli_free_result($lands);
mysqli_free_result($schemes);
?>