<?php
require_once 'includes/auth.php';

// Fetch user details
$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$isAdmin = $_SESSION['isAdmin'];

// Fetch stats for dashboard
$stats_query = $isAdmin
    ? "SELECT 
        SUM(l.land_size) as total_land,
        COUNT(DISTINCT l.id) as land_count,
        COUNT(DISTINCT s.scheme_id) as active_schemes
       FROM lands l
       LEFT JOIN regions r ON l.region = r.region_name
       LEFT JOIN region_schemes rs ON r.region_id = rs.region_id
       LEFT JOIN beneficiary_schemes s ON rs.scheme_id = s.scheme_id"
    : "SELECT 
        SUM(l.land_size) as total_land,
        COUNT(DISTINCT l.id) as land_count,
        COUNT(DISTINCT s.scheme_id) as active_schemes
       FROM lands l
       LEFT JOIN regions r ON l.region = r.region_name
       LEFT JOIN region_schemes rs ON r.region_id = rs.region_id
       LEFT JOIN beneficiary_schemes s ON rs.scheme_id = s.scheme_id
       WHERE l.user_id = ?";
$stmt = mysqli_prepare($conn, $stats_query);
if (!$isAdmin) {
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
}
mysqli_stmt_execute($stmt);
$stats_result = mysqli_stmt_get_result($stmt);
$stats = mysqli_fetch_assoc($stats_result) ?: ['total_land' => 0, 'land_count' => 0, 'active_schemes' => 0];
mysqli_stmt_close($stmt);

// Fetch data for Bar Chart: Land size per region
$land_query = $isAdmin
    ? "SELECT region, SUM(land_size) as total_land FROM lands GROUP BY region"
    : "SELECT region, SUM(land_size) as total_land FROM lands WHERE user_id = ? GROUP BY region";
$stmt = mysqli_prepare($conn, $land_query);
if (!$isAdmin) {
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
}
mysqli_stmt_execute($stmt);
$land_result = mysqli_stmt_get_result($stmt);
$land_data = [];
$land_labels = [];
while ($row = mysqli_fetch_assoc($land_result)) {
    $land_labels[] = $row['region'];
    $land_data[] = $row['total_land'];
}
mysqli_stmt_close($stmt);

// Fetch data for Line Chart: Activity log entries over time (last 7 days)
$activity_query = $isAdmin
    ? "SELECT DATE(created_at) as date, COUNT(*) as action_count 
       FROM activity_log 
       WHERE created_at >= CURDATE() - INTERVAL 7 DAY 
       GROUP BY DATE(created_at)"
    : "SELECT DATE(created_at) as date, COUNT(*) as action_count 
       FROM activity_log 
       WHERE user_id = ? AND created_at >= CURDATE() - INTERVAL 7 DAY 
       GROUP BY DATE(created_at)";
$stmt = mysqli_prepare($conn, $activity_query);
if (!$isAdmin) {
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
}
mysqli_stmt_execute($stmt);
$activity_result = mysqli_stmt_get_result($stmt);
$activity_labels = [];
$activity_data = [];
$dates = [];
for ($i = 6; $i >= 0; $i--) {
    $dates[date('Y-m-d', strtotime("-$i days"))] = 0;
}
while ($row = mysqli_fetch_assoc($activity_result)) {
    $dates[$row['date']] = $row['action_count'];
}
foreach ($dates as $date => $count) {
    $activity_labels[] = date('M d', strtotime($date));
    $activity_data[] = $count;
}
mysqli_stmt_close($stmt);

// Fetch data for Pie Chart: Beneficiary counts by scheme status
$scheme_query = "SELECT rs.implementation_status, SUM(rs.beneficiaries_count) as total_beneficiaries
                 FROM region_schemes rs
                 GROUP BY rs.implementation_status";
$scheme_result = mysqli_query($conn, $scheme_query);
$scheme_labels = [];
$scheme_data = [];
while ($row = mysqli_fetch_assoc($scheme_result)) {
    $scheme_labels[] = ucfirst($row['implementation_status']);
    $scheme_data[] = $row['total_beneficiaries'] ?? 0;
}
mysqli_free_result($scheme_result);

// Check if data is available for graphs
$land_empty = empty($land_data);
$activity_empty = empty(array_filter($activity_data));
$scheme_empty = empty(array_filter($scheme_data));

include 'header.php';
?>

<main class="flex-1 p-8">
    <div class="max-w-6xl mx-auto">
        <!-- Welcome Section -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h1 class="text-2xl font-bold text-green-800">Welcome, <?php echo htmlspecialchars($full_name); ?>!</h1>
            <p class="text-gray-600 mt-2">Here's an overview of your agricultural data and activities.</p>
        </div>

        <!-- Stats Section -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-lg font-semibold text-gray-700">Total Land Size</h2>
                <p class="text-2xl font-bold text-green-600"><?php echo number_format($stats['total_land'], 2); ?> ha</p>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-lg font-semibold text-gray-700">Number of Lands</h2>
                <p class="text-2xl font-bold text-green-600"><?php echo $stats['land_count']; ?></p>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-lg font-semibold text-gray-700">Active Schemes</h2>
                <p class="text-2xl font-bold text-green-600"><?php echo $stats['active_schemes']; ?></p>
            </div>
        </div>

        <!-- Graphs Section -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Bar Chart: Land Size per Region -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-lg font-semibold text-gray-700 mb-4">Land Size by Region</h2>
                <?php if ($land_empty): ?>
                    <p class="text-gray-600">No land data available.</p>
                <?php else: ?>
                    <canvas id="landChart" height="200"></canvas>
                <?php endif; ?>
            </div>

            <!-- Line Chart: Activity Log Over Time -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-lg font-semibold text-gray-700 mb-4">Activity Trends (Last 7 Days)</h2>
                <?php if ($activity_empty): ?>
                    <p class="text-gray-600">No activity data available.</p>
                <?php else: ?>
                    <canvas id="activityChart" height="200"></canvas>
                <?php endif; ?>
            </div>

            <!-- Pie Chart: Beneficiary Counts by Scheme Status -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-lg font-semibold text-gray-700 mb-4">Scheme Beneficiaries by Status</h2>
                <?php if ($scheme_empty): ?>
                    <p class="text-gray-600">No scheme data available.</p>
                <?php else: ?>
                    <canvas id="schemeChart" height="200"></canvas>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
<?php if (!$land_empty): ?>
// Bar Chart: Land Size per Region
const landChart = new Chart(document.getElementById('landChart'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($land_labels); ?>,
        datasets: [{
            label: 'Total Land Size (ha)',
            data: <?php echo json_encode($land_data); ?>,
            backgroundColor: 'rgba(46, 125, 50, 0.6)', // Green shade
            borderColor: 'rgba(46, 125, 50, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: { beginAtZero: true, title: { display: true, text: 'Land Size (ha)' } },
            x: { title: { display: true, text: 'Region' } }
        },
        plugins: { legend: { display: false } }
    }
});
<?php endif; ?>

<?php if (!$activity_empty): ?>
// Line Chart: Activity Log Over Time
const activityChart = new Chart(document.getElementById('activityChart'), {
    type: 'line',
    data: {
        labels: <?php echo json_encode($activity_labels); ?>,
        datasets: [{
            label: 'Actions per Day',
            data: <?php echo json_encode($activity_data); ?>,
            borderColor: 'rgba(199, 34, 91, 1)', // Pink shade (#c2185b)
            backgroundColor: 'rgba(199, 34, 91, 0.2)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        scales: {
            y: { beginAtZero: true, title: { display: true, text: 'Number of Actions' } },
            x: { title: { display: true, text: 'Date' } }
        },
        plugins: { legend: { display: false } }
    }
});
<?php endif; ?>

<?php if (!$scheme_empty): ?>
// Pie Chart: Beneficiary Counts by Scheme Status
const schemeChart = new Chart(document.getElementById('schemeChart'), {
    type: 'pie',
    data: {
        labels: <?php echo json_encode($scheme_labels); ?>,
        datasets: [{
            label: 'Beneficiaries',
            data: <?php echo json_encode($scheme_data); ?>,
            backgroundColor: [
                'rgba(46, 125, 50, 0.6)', // Green for ongoing
                'rgba(199, 34, 91, 0.6)', // Pink for planned
                'rgba(66, 165, 245, 0.6)' // Blue for completed
            ],
            borderColor: [
                'rgba(46, 125, 50, 1)',
                'rgba(199, 34, 91, 1)',
                'rgba(66, 165, 245, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        plugins: { legend: { position: 'bottom' } }
    }
});
<?php endif; ?>
</script>

<?php
mysqli_free_result($stats_result);
include 'footer.php';
?>